package com.example.demo1.common.models;

import java.io.Serializable;

public class GetAllClientsRequest implements Serializable {
    // Pas de contenu nécessaire, c’est juste un signal
}
