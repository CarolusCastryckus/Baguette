package com.example.demo1.client.controllers;

public class VoyageController {
}
